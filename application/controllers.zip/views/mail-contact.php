<div class="cart">
    <table style="width: 100%;">
        <tr><td style="text-transform: capitalize;"><strong>HI <?=$name?>, </strong></td></tr>
        <tr><td style="border-bottom: 1px solid #ccc; padding-bottom: 10px;" >THANK YOU FOR CONTACT ETERNALEAF!</td></tr>
    </table>
    <br />
    
    <table style="width: 100%;">
        <tr><td>Name</td><td>:</td><td><?=$name?></td></tr>
        <tr><td>Email</td><td>:</td><td><?=$email?></td></tr>
        <tr><td>Message</td><td>:</td><td><?=$message?></td></tr>
    </table>
<br />

</div>