<!-- JS Plugins -->
<script src="<?=base_url('assets/frontend/javascripts/device.min.js')?>"></script>
<script src="<?=base_url('assets/frontend/javascripts/modernizr.js')?>" type="text/javascript"></script>
<script src="<?=base_url('assets/frontend/javascripts/retina.js')?>" type="text/javascript"></script>
<script src="<?=base_url('assets/frontend/javascripts/responsive-nav.js')?>" type="text/javascript"></script>
<script src="<?=base_url('assets/frontend/javascripts/navi-slidedown.js')?>" type="text/javascript"></script>
<script src="<?=base_url('assets/frontend/javascripts/jquery.multiscroll.min.js')?>"></script> 
<script src="<?=base_url('assets/frontend/javascripts/equalheights.js')?>" ></script> 
<script src="<?=base_url('assets/frontend/javascripts/jquery.parallax-1.1.3.js')?>" ></script>
<script src="<?=base_url('assets/frontend/javascripts/jquery.bxslider.min.js')?>"></script>
<script src="<?=base_url('assets/frontend/javascripts/jquery.slimmenu.min.js')?>"></script>
<script src="<?=base_url('assets/frontend/javascripts/pace.min.js')?>" ></script> 
<!-- JS Custom Codes --> 