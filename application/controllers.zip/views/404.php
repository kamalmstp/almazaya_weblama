
<?php $this->load->view('sources/header.php')?>
<section class="section-content thecontent container" >
	
        <div class="title-page">
            
            <h2>Page not found</h2>
            <hr />
            
        </div>
       
            <div class="contentpage" style="text-align: center;">
                <img src="<?=base_url("assets/img/404.png")?>" />
            </div>
            
	</section>
    <style>
    .aktif img{
        width:150px !important
    }
    </style>
    <?php $this->load->view('sources/footer-produk.php')?>