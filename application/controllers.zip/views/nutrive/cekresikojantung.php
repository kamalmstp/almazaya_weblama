<!-- full page -->
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

  <!--Add the title of your typeform below-->
  <title>Cek Risiko Jantung Koroner</title>

  <!--CSS styles that ensure your typeform takes up all the available screen space (DO NOT EDIT!)-->
  <style type="text/css">
    body {
	    margin-left: 0px;
	    margin-top: 0px;
	    margin-right: 0px;
	    margin-bottom: 0px;
	
	    width:100%;
	    height:100%;
    }
    </style>
</head>
<body>
  <iframe src="https://arum4.typeform.com/to/g6ozKX" style="position:absolute; top:0px; left:0px; bottom:0px; right:0px; width:100%; height:100%; border:none; margin:0; padding:0; z-index:999999;">
  Your browser doesn't support IFrames
</iframe>
 
</body>
</html>




<!-- partial -->
<!-- Change the width and height values to suit you best -->
<div class="typeform-widget" data-url="https://arum4.typeform.com/to/g6ozKX" data-text="Benecol v2.0" style="width:100%;height:500px;"></div>
<script>(function(){var qs,js,q,s,d=document,gi=d.getElementById,ce=d.createElement,gt=d.getElementsByTagName,id='typef_orm',b='https://s3-eu-west-1.amazonaws.com/share.typeform.com/';if(!gi.call(d,id)){js=ce.call(d,'script');js.id=id;js.src=b+'widget.js';q=gt.call(d,'script')[0];q.parentNode.insertBefore(js,q)}})()</script>


