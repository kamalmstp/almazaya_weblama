<?php $this->load->view('sources/header.php')?>

<!-- About Section -->
    <section id="about">
      <div class="container">
        <h2 class="text-center"><?=$current_page?></h2>
        <div class="row">
          <div class="col-lg-12 ml-auto">
            <?=$isicontent?>
          </div>
          
        </div>
      </div>
    </section>
    

<?php $this->load->view('sources/footer.php')?>