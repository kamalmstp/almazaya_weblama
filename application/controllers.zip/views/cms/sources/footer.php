<footer class="sticky-footer">
          2016 &copy; Content Manangement System by <b><a href="http://brightstars.co.id/">Brightstars</a></b>
      </footer>
      <!--footer section end-->


    </div>
      <!-- main content end-->
  </section>

  <!-- Placed js at the end of the document so the pages load faster -->
  <script src="<?=base_url('assets/backend/js/bootstrap.min.js')?>"></script>
  <script src="<?=base_url('assets/backend/js/modernizr.min.js')?>"></script>
  <script src="<?=base_url('assets/backend/js/jquery.nicescroll.js')?>"></script>

  <script type="text/javascript" language="javascript" src="<?=base_url('assets/backend/js/advanced-datatable/js/jquery.dataTables.js')?>"></script>
  <script type="text/javascript" src="<?=base_url('assets/backend/js/data-tables/DT_bootstrap.js')?>"></script>
  <!--dynamic table initialization -->
  <script src="<?=base_url('assets/backend/js/dynamic_table_init.js')?>"></script>

  <!--file upload-->
  <script type="text/javascript" src="<?=base_url('assets/backend/js/bootstrap-fileupload.min.js')?>"></script>
  
  <!--multi-select-->
  <script type="text/javascript" src="<?=base_url('assets/backend/js/jquery-multi-select/js/jquery.multi-select.js')?>"></script>
  <script type="text/javascript" src="<?=base_url('assets/backend/js/jquery-multi-select/js/jquery.quicksearch.js')?>"></script>
  <script src="<?=base_url('assets/backend/js/multi-select-init.js')?>"></script>
  <!--common scripts for all pages-->
  <script src="<?=base_url('assets/backend/js/scripts.js')?>"></script>
  
  <script type="text/javascript" src="<?=base_url('assets/backend/js/jquery.validate.min.js')?>"></script>
    <script src="<?=base_url('assets/backend/js/validation-init-delete.js')?>"></script>
    <link href="<?php echo base_url('assets/backend/css/jquery-ui.css')?>" rel="stylesheet">

</body>
</html>
