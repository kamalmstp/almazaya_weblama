<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends Base_Controller {
    public function __construct(){
        parent::__construct();
        date_default_timezone_set("Asia/Bangkok"); 
    }
    public function index(){
        
        $idpages = $this->db->query('SELECT pages.id,language.id as idlang,pages.meta_title,pages.meta_description,pages.sister,pages.title,pages.idmodule,language.lang_code,language.use_default FROM pages INNER JOIN language on pages.idlanguage=language.id WHERE pages.link = "'.$this->link.'" AND language.lang_code = "'.$this->bahasa.'"')->result();
        if (isset($idpages[0]->id)){
            $this->data['rec'] = $this->db->query('SELECT title,pic,link,sisterpages FROM banner WHERE sisterpages = '.$idpages[0]->sister.' ORDER BY posisi asc')->result_array();
            if($idpages[0]->use_default == 0){
                $this->data['codebahasa'] = $idpages[0]->lang_code.'/';
            }else{
                $this->data['codebahasa'] = '';
            }
            $this->data['lang'] = $this->db->query('SELECT language.id, language.title, language.lang_code, language.pic, language.use_default, pages.link FROM `language` INNER JOIN pages on pages.idlanguage=language.id WHERE pages.sister = '.$idpages[0]->sister)->result_array();
            //echo $idpages[0]->idlang;
            $this->data['langnow'] = $idpages[0]->idlang;
            $banner = $this->db->query('SELECT banner.pic,banner.title,banner.link,banner.description,banner.pic2 FROM `banner` where banner.idlanguage = '.$idpages[0]->idlang.' AND banner.hapus=0 AND banner.draft=0 order by banner.posisi  ASC limit 0,10')->result_array();
            $this->data['rec_banner'] = $banner;
            
            
            $artikel = $this->db->query('SELECT a.title,a.thumb,a.pic,a.cretime,a.description,a.link as link_news,c.title as title_cat,d.link as link_detail FROM `artikel` a LEFT JOIN kategori_artikel c ON a.cat=c.id LEFT JOIN pages d ON c.sisterpages=d.sister where a.deleted=0 AND a.hidden=0 AND a.idlanguage = '.$idpages[0]->idlang.' AND a.title != "" order by a.crdate_set DESC limit 0,4')->result_array();
            $count_artikel = $this->db->query('SELECT count(*) as total FROM `artikel` a LEFT JOIN kategori_artikel c ON a.cat=c.id LEFT JOIN pages d ON c.sisterpages=d.sister where a.deleted=0 AND a.hidden=0 AND a.idlanguage = '.$idpages[0]->idlang.' AND a.title != "" order by a.crdate_set ASC')->result_array();
            $this->data['rec_artikel'] = $artikel;
            $this->data['total_artikel'] = $count_artikel[0]["total"];
        }
        
        $this->data['controller']=$this; 
        $this->data['link'] = $this->link;
        $this->data['current_link_page'] = $this->link;
        $this->data['one_page'] = $this->db->query('SELECT a.* FROM one_page_many_section a LEFT JOIN pages b ON a.sisterpages=b.sister WHERE b.idlanguage = '.$idpages[0]->idlang.' AND a.idlanguage= '.$idpages[0]->idlang.' AND b.sister='.$idpages[0]->sister.' and a.draft=0 AND a.hapus=0 ORDER BY a.posisi ASC')->result_array();
        //echo "<pre>";
//        print_r($this->data['one_page']);
//        echo $this->id_bahasa;
        //$session_login = $this->session->userdata('eternaleaf_login');
        //echo "<pre>";
        //$data_session = $this->session->all_userdata();
        //print_r($data_session["login_user"]);
        //die();
        
        $artikel = $this->db->query('SELECT a.title,a.thumb,a.pic,a.cretime,a.description,a.link as link_news,c.title as title_cat,d.link as link_detail FROM `artikel` a LEFT JOIN kategori_artikel c ON a.cat=c.id LEFT JOIN pages d ON c.sisterpages=d.sister where a.deleted=0 AND a.show=1 AND a.hidden=0 AND a.idlanguage = '.$idpages[0]->idlang.' AND d.idlanguage = '.$idpages[0]->idlang.' AND a.title != "" order by a.posisi DESC limit 0,4')->result_array();
        //echo "<pre>";
        //print_r('SELECT a.title,a.thumb,a.pic,a.cretime,a.description,a.link as link_news,c.title as title_cat,d.link as link_detail FROM `artikel` a LEFT JOIN kategori_artikel c ON a.cat=c.id LEFT JOIN pages d ON c.sisterpages=d.sister where a.deleted=0 AND a.hidden=0 AND a.idlanguage = '.$idpages[0]->idlang.' AND c.idlanguage = '.$idpages[0]->idlang.' AND d.idlanguage = '.$idpages[0]->idlang.' AND a.title != "" order by a.crdate_set DESC limit 0,4');
        $this->data['parallax']=1; 
        $this->data['artikel'] = $artikel;
        
        $this->data['meta_title'] = $idpages[0]->title;
        if($idpages[0]->meta_title != ""){
            $this->data['meta_title'] = $idpages[0]->meta_title;
        }
        $this->data['meta_description'] = "";
        if($idpages[0]->meta_description != ""){
            $this->data['meta_description'] = $idpages[0]->meta_description;
        }
        
        $prestasi = $this->db->query('SELECT title,description,pic FROM prestasi WHERE draft=0 AND hapus=0')->result_array();
        $this->data['prestasi'] = $prestasi;
        
        $aktifitas = $this->db->query('SELECT a.title,a.description,a.pic,DATE_FORMAT(a.cretime,"%d %M %Y") AS datenya,a.link,b.link as link_pages FROM aktifitas a LEFT JOIN pages b ON a.idmenu=b.record WHERE a.draft=0 AND a.hapus=0 LIMIT 0,3')->result_array();
        $this->data['aktifitas'] = $aktifitas;
        
        $headline = $this->db->query('SELECT title,description FROM headline WHERE id=1')->result_array();
        $this->data['headline'] = $headline;
      
        
        $kindergaten_curriculum = $this->db->query('SELECT title,description,pic FROM `content` WHERE idmenu=108')->result_array();  
        $this->data['kindergaten1_curricullum'] = $kindergaten_curriculum;
        
        $kindergaten1 = $this->db->query('SELECT title,description,pic FROM `content` WHERE idmenu=107')->result_array();  
        $this->data['kindergaten1'] = $kindergaten1;
        
        $kurikulum_kindergaten = $this->db->query('SELECT title,description FROM `kurikulum` WHERE idmenu=109')->result_array();
        $this->data['kurikulum_kindergaten'] = $kurikulum_kindergaten;
        
        $primary_curriculum = $this->db->query('SELECT title,description,pic FROM `content` WHERE idmenu=112')->result_array();  
        $this->data['primary_curricullum'] = $primary_curriculum;
        
        $primary1 = $this->db->query('SELECT title,description,pic FROM `content` WHERE idmenu=111')->result_array();  
        $this->data['primary1'] = $primary1;
        
        $kurikulum_primary = $this->db->query('SELECT title,description FROM `kurikulum` WHERE idmenu=113')->result_array();
        $this->data['kurikulum_primary'] = $kurikulum_primary;
       
        
        $seondary_curriculum = $this->db->query('SELECT title,description,pic FROM `content` WHERE idmenu=116')->result_array();  
        $this->data['seondary_curricullum'] = $seondary_curriculum;
        
        $seondary1 = $this->db->query('SELECT title,description,pic FROM `content` WHERE idmenu=115')->result_array();  
        $this->data['seondary1'] = $seondary1;
        
        $kurikulum_seondary = $this->db->query('SELECT title,description FROM `kurikulum` WHERE idmenu=117')->result_array();
        $this->data['kurikulum_seondary'] = $kurikulum_seondary;
        
        
        $profile = $this->db->query('SELECT a.title,a.description,a.pic,a.link FROM `content` a where a.idmenu=86 AND a.idlanguage = '.$idpages[0]->idlang.'')->result_array();
        $this->data['profile'] = $profile;
        
        $query_testimonial = $this->db->query('SELECT * FROM `testimonial` WHERE hapus=0')->result_array();
        $this->data['rec_testimonial'] = $query_testimonial;
        
        $query_aktifitas = $this->db->query('SELECT a.*,b.link as link_pages,b.title as cat FROM `artikel` a LEFT JOIN pages b ON a.cat=b.id WHERE a.hapus=0  AND deleted=0  LIMIT 0,6')->result_array();
        $this->data['rec_aktifitas'] = $query_aktifitas;
        
        $query_rec_gallery = $this->db->query('SELECT a.*,b.link as link_pages,b.title as cat FROM `galeri` a LEFT JOIN pages b ON a.cat=b.id  WHERE a.hapus=0 AND deleted=0  AND a.deleted=0 LIMIT 0,6')->result_array();
        $this->data['rec_gallery'] = $query_rec_gallery;
        
        
        $level = $this->db->query('SELECT * FROM `level` WHERE deleted=0 AND hidden=0 AND hapus=0')->result_array();  
        $this->data['level'] = $level;
        
        $this->load->view('banner',$this->data);
    }
    function count_submenu($sister){
        $countnya = $this->db->query('SELECT COUNT(*) FROM pages WHERE sister='.$sister)->result_array();
        
    }
    function get_curricullum($id){
        $rec = $this->db->query("SELECT * FROM kurikulum WHERE cat = $id AND hapus=0 ORDER BY title ASC")->result_array();
        return $rec;
    }
    function show_menu_lang(){
        $lang_menu = $this->db->query('SELECT title,id,lang_code,use_default FROM language WHERE draft = 0 AND hapus=0 ORDER BY use_default DESC')->result_array();
        $htmlString = "";
        $konter = 1;
        $countmenu = count($lang_menu);
        foreach ($lang_menu as $mn){
            if ($mn["use_default"] == 1){
                if (count($this->segs) == 2) {
                    if ($this->link_bahasa == ""){
                        $htmlString .= "<option selected='selected' value='".base_url($this->getMenuOtherLang($mn["id"],$this->link))."'>".strtoupper($mn["lang_code"])."</option>";
                    }else{
                        $htmlString .= "<option value='".base_url($this->getMenuOtherLang($mn["id"],$this->link))."'>".strtoupper($mn["lang_code"])."</option>";
                    }
                }else{
                    if ($this->link_bahasa == ""){
                        $htmlString .= "<option selected='selected' value='".base_url()."'>".strtoupper($mn["lang_code"])."</option>";
                    }else{
                        $htmlString .= "<option value='".base_url()."'>".strtoupper($mn["lang_code"])."</option>";
                    }
                }
            }else{
                if (count($this->segs) == 2) {
                    /*ada code lang bahasa dan di halaman selain home */
                    if ($mn["lang_code"] == substr($this->link_bahasa, 0, -1)){
                        $htmlString .= "<option selected='selected' value='".base_url("".$mn["lang_code"]."")."'>".strtoupper($mn["lang_code"])."</option>";
                    }else{
                        $htmlString .= "<option value='".base_url("".$mn["lang_code"]."/".$this->getMenuOtherLang($mn["id"],$this->link))."'>".strtoupper($mn["lang_code"])."</option>";
                    }
                }else{
                    if ($mn["lang_code"] == substr($this->link_bahasa, 0, -1)){
                        $htmlString .= "<option selected='selected' value='".base_url("".$mn["lang_code"]."")."'>".strtoupper($mn["lang_code"])."</option>";
                    }else{
                        if (isset($this->segs[1])){
                            $htmlString .= "<option value='".base_url("".$mn["lang_code"]."/".$this->getMenuOtherLang($mn["id"],$this->segs[1]))."'>".strtoupper($mn["lang_code"])."</option>";
                        }else{
                            $htmlString .= "<option value='".base_url("".$mn["lang_code"]."")."'>".strtoupper($mn["lang_code"])."</option>";
                        }
                    }
                }
            }
            $konter++;
        }
        return $htmlString;
    }
    
    function getbanner($idmenu){
        $rec = $this->db->query('SELECT link,title,description,pic FROM banner WHERE draft = 0 AND hapus=0 AND idlanguage='.$this->id_bahasa.' ORDER BY posisi ASC')->result_array();
    
        return $rec;
    }
}
